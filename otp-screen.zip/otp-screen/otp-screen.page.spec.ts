import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtpScreenPage } from './otp-screen.page';

describe('OtpScreenPage', () => {
  let component: OtpScreenPage;
  let fixture: ComponentFixture<OtpScreenPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtpScreenPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtpScreenPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
