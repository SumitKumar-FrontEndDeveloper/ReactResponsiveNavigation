import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup , Validators , FormControl } from '@angular/forms';
import { NavController, NavParams } from '@ionic/angular';
import { ConstantsService } from '../api/constants.service';
import { UtilService } from '../api/util.service';
import { LocalStorageService } from '../api/local-storage.service';
import { SharedServiceService } from '../api/shared-service.service';
@Component({
  selector: 'app-otp-screen',
  templateUrl: './otp-screen.page.html',
  styleUrls: ['./otp-screen.page.scss'],
  providers:[SharedServiceService,LocalStorageService]
})
export class OtpScreenPage implements OnInit {
  otpForm: FormGroup;
  otpp1:any;
  otpp2:any;
  otpp3:any;
  otpp4:any;
  mobile:any;
  passwordType:string ='password';
  constructor(private localStorage:LocalStorageService,readonly sharedService:SharedServiceService,readonly util:UtilService,readonly constantsService:ConstantsService,private formBuilder: FormBuilder,public navCtrl: NavController) {
    this.mobile=this.localStorage.getStorage('mobile');
  }

  ngOnInit() {
   
  }
    ionViewDidLeave() {
        console.log("leving");
        window.scroll=null;
    }
    checkOtp(otp) {
      var credentialsForm={
        "otp": otp,
        "deviceToken" : this.localStorage.getStorage("deviceToken")
      };
      console.log(credentialsForm);
      this.util.showLoading();
      this.sharedService.CallDataWithOutToken("verifyOtp", credentialsForm).subscribe(
        result => {
          console.log("otp Result:: "+result);
          if (result.statusCode==200) {
              this.util.stopLoading();
              this.util.redirectToPage('tabs/home');
              this.localStorage.setStorage("userdata",result.userdata);
              this.localStorage.setStorage("token",result.token);
          }
          else { 
            this.resetPin();
            this.util.stopLoading();
            this.util.stopLoading();
            this.util.showToast(result.msg,3000 ,"top");
            this.util.stopLoading();
          }
        }
      );
    }
    
    otpController(event,next,prev){
      console.log(event);
      if(event.target.value.length < 1 && prev){
        console.log("if previouw");
        prev.setFocus();
      }
      else if(next && event.target.value.length>0){
        console.log("if next");
        next.setFocus();
      }
      else {
        
      setTimeout(()=>{
          console.log(this.otpp1);
          console.log(this.otpp2);
          console.log(this.otpp3);
          console.log(this.otpp4);
          let otpPin=this.otpp1+this.otpp2+this.otpp3+this.otpp4;
          console.log(otpPin);
          this.checkOtp(otpPin);
        },500); 
        
        return 0;
      }
  }
  resetPin() {
    this.otpp1=null;
    this.otpp2=null;
    this.otpp3=null;
    this.otpp4=null;
  }

  resendOtp() {
        var credentialsForm={
              "mobile": this.mobile,
              "country_code" : 91
            };
            this.localStorage.setStorage('mobile',this.mobile);
            
            this.sharedService.CallDataWithOutToken("login", credentialsForm).subscribe(
              result => {
                if (result.statusCode==200) {
                    this.util.stopLoading();
                    this.util.showToast(this.constantsService.resendOtp.replace("{mobile}",this.mobile),3000 ,"top");
                    alert(result.otp);
                    
                }
                else {
                  this.util.stopLoading();
                  this.util.showToast(result.msg,3000 ,"top");
                }
              }
            );
          
      }
}

